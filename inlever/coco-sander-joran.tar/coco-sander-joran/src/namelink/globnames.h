#ifndef _NAMELINKGLOBNAMES_H_
#define _NAMELINKGLOBNAMES_H_

#include "types.h"

extern node* NAMELINKGLOBNAMESglobdef(node *arg_node, info *arg_info);
extern node* NAMELINKGLOBNAMESglobdec(node *arg_node, info *arg_info);
extern node* NAMELINKGLOBNAMESfundef(node *arg_node, info *arg_info);
extern node* NAMELINKGLOBNAMESfundec(node *arg_node, info *arg_info);

#endif /* _NAMELINKGLOBNAMES_H_ */
