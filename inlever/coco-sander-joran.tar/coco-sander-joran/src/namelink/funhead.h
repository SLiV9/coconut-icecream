#ifndef _NAMELINKFUNHEAD_H_
#define _NAMELINKFUNHEAD_H_

#include "types.h"

extern node* NAMELINKFUNHEADglobdef(node *arg_node, info *arg_info);
extern node* NAMELINKFUNHEADglobdec(node *arg_node, info *arg_info);
extern node* NAMELINKFUNHEADfundef(node *arg_node, info *arg_info);
extern node* NAMELINKFUNHEADfundec(node *arg_node, info *arg_info);

#endif /* _NAMELINKFUNHEAD_H_ */
