#ifndef _MYSCP_H_
#define _MYSCP_H_

#include "types.h"

extern node *MYSCPdoScanParse( node *syntaxtree);

#endif /* _MYSCP_H_ */
