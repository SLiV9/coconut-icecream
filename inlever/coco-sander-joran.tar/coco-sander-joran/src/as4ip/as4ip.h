#ifndef _AS4IP_H_
#define _AS4IP_H_

#include "types.h"

extern node* AS4IPvarcall(node *arg_node, info *arg_info);
extern node* AS4IPvarlet(node *arg_node, info *arg_info);
extern node *AS4IPdoIdPrefix( node *syntaxtree);

#endif /* _AS4IP_H_ */
