#ifndef _GSCLEANUP_H_
#define _GSCLEANUP_H_

#include "types.h"

extern node* GSCLEANUPdeclars(node *arg_node, info *arg_info);

extern node *GSCLEANUPdoReplace( node *syntaxtree);

#endif /* _GSCLEANUP_H_ */
