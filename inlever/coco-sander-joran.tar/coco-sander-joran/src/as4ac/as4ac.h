#ifndef _AS4AC_H_
#define _AS4AC_H_

#include "types.h"

extern node* AS4ACbinop(node *arg_node, info *arg_info);
extern node *AS4ACdoCount( node *syntaxtree);

#endif /* _AS4AC_H_ */
