vtype getType(node* nd);
int getDepth(node* nd);

int getExprsLen(node* arg_node);
int getDimDecsLen(node* arg_node);
