#ifndef _MYCPP_H_
#define _MYCPP_H_

#include "types.h"

extern node *MYCPPdoPreprocessing( node *syntaxtree);

#endif /* _MYCPP_H_ */
